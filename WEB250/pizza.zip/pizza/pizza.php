<!DOCTYPE html>
<html>
<title>WEB 250 Pizzeria</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Amatic+SC">
 
<link rel="stylesheet" href="./css/pizza.css">
 
<body>
<link rel="stylesheet" href="./css/pizza.css">
<?php include "./header.html" ?> 



<!-- Footer -->
<footer class="w3-center w3-black w3-padding-48 w3-xxlarge">
  <p>Powered by <a href="https://www.w3schools.com/w3css/default.asp" title="W3.CSS" target="_blank" class="w3-hover-text-green">w3.css</a></p>
</footer>
<script src="./scripts/pizzascripts.js"></script>


</body>
</html>

