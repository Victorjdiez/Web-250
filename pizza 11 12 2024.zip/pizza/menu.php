<!DOCTYPE html>
<html>
    <body>
    <?php include "./includes/header.php" ?> 


    <!-- Menu Container -->
    <div class="w3-container w3-black w3-padding-64 w3-xxlarge" id="menu">
      <div class="w3-content">

        <h1 class="w3-center w3-jumbo" style="margin-bottom:64px">THE MENU</h1>

        <?php
        echo "<h1> Daily Special: One Starter and One Entree</h1>";


        $specialStarter = "Bruschetta";
        $specialEntree = "Seafood Pasta";
        $discountPercent =  .25;
        $starterOriginalPrice = 8.50;
        $entreeOriginalPrice = 25.50;
        $specialOriginalPrice = $starterOriginalPrice + $entreeOriginalPrice;
        $discountAmount = $specialOriginalPrice * $discountPercent;
        $specialDiscountPrice = $specialOriginalPrice - $discountAmount;

        echo "<p>Today: $specialStarter and $specialEntree. <br>";
        echo "Discount today: $discountPercent %<br>";
        echo "Original price:$ $specialOriginalPrice<br>";
        echo "Discount price: $ $specialDiscountPrice</p><br>";
        ?>
        <div class="w3-row w3-center w3-border w3-border-dark-grey">
        <a href="javascript:void(0)" onclick="openMenu(event, 'Pizza');" id="myLink">
          <div class="w3-col s4 tablink w3-padding-large w3-hover-red">Pizza</div>
        </a>
        <a href="javascript:void(0)" onclick="openMenu(event, 'Pasta');">
          <div class="w3-col s4 tablink w3-padding-large w3-hover-red">Pasta</div>
        </a>
        <a href="javascript:void(0)" onclick="openMenu(event, 'Starter');">
          <div class="w3-col s4 tablink w3-padding-large w3-hover-red">Starter</div>
        </a>
      </div>
      
      <?php
      $sql = "SELECT `menu_item_id`, `menu_item_category`, `menu_item_name`, `menu_item_description`, `menu_item_emphasis`, `menu_item_price` FROM `menu`";
      $result = $dbc->query($sql);
      // I'm close to given up
      if ($result->num_rows > 0) {
          $pizzas = [];
          $pastas = [];
          $starters = [];
      // IT WORKED?!?!?!?
          while ($row = $result->fetch_assoc()) {
              switch (strtolower($row['menu_item_category'])) {
                  case 'pizza':
                      $pizzas[] = $row;
                      break;
                  case 'pasta':
                      $pastas[] = $row;
                      break;
                  case 'starter':
                      $starters[] = $row;
                      break;
              }
          }
      } else {
          echo "0 results";
      }
      ?>
      
      <div id="Pizza" class="w3-container menu w3-padding-32 w3-white" style="display: none;">
        <?php foreach ($pizzas as $pizza): ?>
          <h1><b>Name: <?= $pizza['menu_item_name'] ?></b>
            <span class="w3-right w3-tag w3-dark-grey w3-round">$ <?= $pizza['menu_item_price'] ?></span>
          </h1>
          <p class="w3-text-grey"><?= $pizza['menu_item_description'] ?></p>
          <hr>
        <?php endforeach; ?>
      </div>
      
      <div id="Pasta" class="w3-container menu w3-padding-32 w3-white" style="display: none;">
        <?php foreach ($pastas as $pasta): ?>
          <h1><b>Name: <?= $pasta['menu_item_name'] ?></b>
            <span class="w3-right w3-tag w3-dark-grey w3-round">$ <?= $pasta['menu_item_price'] ?></span>
          </h1>
          <p class="w3-text-grey"><?= $pasta['menu_item_description'] ?></p>
          <hr>
        <?php endforeach; ?>
      </div>
      
      <div id="Starter" class="w3-container menu w3-padding-32 w3-white" style="display: none;">
        <?php foreach ($starters as $starter): ?>
          <h1><b>Name: <?= $starter['menu_item_name'] ?></b>
            <span class="w3-right w3-tag w3-dark-grey w3-round">$ <?= $starter['menu_item_price'] ?></span>
          </h1>
          <p class="w3-text-grey"><?= $starter['menu_item_description'] ?></p>
          <hr>
        <?php endforeach; ?>
      </div>
      
      <script src="./scripts/pizzascripts.js"></script>
      
    <?php include "./includes/footer.html" ?> 
    </body>
</html>