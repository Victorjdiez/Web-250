<!DOCTYPE html>
<html>
    
    <body>
        <?php include "./includes/header.php"; ?> 


        <?php

#-----
# Access session.
session_start() ;

# Redirect if not logged in.
if ( !isset( $_SESSION[ 'user_id' ] ) ) { require ( 'login_tools.php' ) ; load() ; }
#------

if (isset($_POST['add'])) {
    $name = mysqli_real_escape_string($dbc, $_POST['menu_item_name']);


    $query = "INSERT INTO menu (menu_item_name) VALUES ('$name')";
    echo $query;


    if (mysqli_query($dbc, $query)) {
        echo "New menu item added successfully!";
    
    } else {
        echo "Error: " . mysqli_error($dbc);
    }
}


if (isset($_POST['submit_add'])) {
    $name = mysqli_real_escape_string($dbc, $_POST['menu_item_name']);
    $catagory = mysqli_real_escape_string($dbc, $_POST['menu_item_category']);
    $description = mysqli_real_escape_string($dbc, $_POST['menu_item_description']);
    $price = mysqli_real_escape_string($dbc, $_POST['menu_item_price']);
   //Catagory:        <input type="text" name="menu_item_category" ><br>
    $query = "INSERT INTO menu (menu_item_name, menu_item_category, menu_item_description, menu_item_price) VALUES ('$name', '$catagory','$description', $price)";
    echo $query;


    if (mysqli_query($dbc, $query)) {
        echo "New menu item added successfully!";
        header("Location: " . $_SERVER['PHP_SELF']);

        exit();
    } else {
        echo "Error: " . mysqli_error($dbc);
    }
}

if (isset($_POST['submit_update'])) {
    $id = mysqli_real_escape_string($dbc, $_POST['menu_item_id']);
    $name = mysqli_real_escape_string($dbc, $_POST['menu_item_name']);
    $description = mysqli_real_escape_string($dbc, $_POST['menu_item_description']);
    $price = mysqli_real_escape_string($dbc, $_POST['menu_item_price']);

    $query = "UPDATE menu SET menu_item_name='$name', menu_item_description='$description', menu_item_price='$price' WHERE menu_item_id='$id'";
    if (mysqli_query($dbc, $query)) {
        echo "Menu item updated successfully!";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        echo "Error: " . mysqli_error($dbc);
    }
}

if (isset($_POST['submit_delete'])) {
    $id = mysqli_real_escape_string($dbc, $_POST['menu_item_id']);

    $query = "DELETE FROM menu WHERE menu_item_id='$id'";
    if (mysqli_query($dbc, $query)) {
        echo "Menu item deleted successfully!";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        echo "Error: " . mysqli_error($dbc);
    }
}


                   
                    ?>



     
        <!-- Menu Container -->
        <div class="w3-container w3-black w3-padding-64 w3-xxlarge" id="menu">
            <div class="w3-content">

                <h1 class="w3-center w3-jumbo" style="margin-bottom:64px">THE MENU</h1>

                <div class="w3-col l6 w3-padding-large">
    <h1 class="w3-center"> </h1>

    <div style="display: flex; gap: 20px;">
        <div style="flex: 1;">
            <h4>Add New Menu Item:</h4>
            <form action="" method="post">
                Name: <input type="text" name="menu_item_name"><br>
                Category: <input type="text" name="menu_item_category"><br>
                Description: <input type="text" name="menu_item_description"><br>
                Price: <input type="number" name="menu_item_price"><br>
                <button type="submit" name="submit_add">Add</button>
            </form>
        </div>

        <div style="flex: 1;">
            <h4>Update Menu Item:</h4>
            <form action="" method="post">
                Id: <input type="text" name="menu_item_id" required><br>
                Name: <input type="text" name="menu_item_name" required><br>
                Description: <input type="text" name="menu_item_description" required><br>
                Price: <input type="number" name="menu_item_price" required><br>
                <button type="submit" name="submit_update">Update</button>
            </form>
        </div>

        <div style="flex: 1;">
            <h4>Delete Menu Item:</h4>
            <form action="" method="post">
                Id: <input type="text" name="menu_item_id" required><br>
                <button type="submit" name="submit_delete">Delete</button>
            </form>
        </div>
    </div>
</div>

                    <h1 class="w3-center"> </h1>
                    <?php
                    $sql = "SELECT `menu_item_id`, `menu_item_category`, `menu_item_name`, `menu_item_description`, `menu_item_emphasis`, `menu_item_price` FROM `menu`";
                    $result = $dbc->query($sql);
                    
                    if (!$result) {
                        echo "Query Error: " . mysqli_error($dbc);
                    } elseif ($result->num_rows > 0) {
                        
                        echo "<table border='1'>
                        <tr>
                            <th>Id</th>
                            <th>Category</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Emphasis</th>
                            <th>Price</th>
                        </tr>";
            
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['menu_item_id']}</td>
                            <td>{$row['menu_item_category']}</td>
                            <td>{$row['menu_item_name']}</td>
                            <td>{$row['menu_item_description']}</td>
                            <td>{$row['menu_item_emphasis']}</td>
                            <td>\${$row['menu_item_price']}</td>
                          </tr>";
                }
                
                echo "</table>";
            } else {
                echo "0 results";
            }
                    ?>

                </div><br>

            </div>
        </div>

      
        
        <?php include "./includes/footer.html"; ?> 
    </body>
</html>
